package com.example.todolistapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class TaskAdapter extends ArrayAdapter<String> {

    private final DatabaseHelper db;

    public TaskAdapter(Context context, ArrayList<String> tasks, DatabaseHelper db) {
        super(context, 0, tasks);
        this.db = db;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_item, parent, false);
        }

        String task = getItem(position);
        TextView textViewTask = convertView.findViewById(R.id.textViewTask);
        Button buttonDelete = convertView.findViewById(R.id.buttonDelete);

        textViewTask.setText(task);
        buttonDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                db.deleteTask(task);
                remove(task);
                notifyDataSetChanged();
            }
        });

        return convertView;
    }
}

